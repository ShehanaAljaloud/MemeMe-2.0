//
//  AppDelegate.swift
//  MemeMe 1.0
//
//  Created by Shehana Aljaloud on 13/04/2019.
//  Copyright © 2019 Shehana Aljaloud. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var memes = [Meme]()

}
