//
//  SendMemeCollectionViewCell.swift
//  MemeMe 1.0
//
//  Created by Shehana Aljaloud on 18/05/2019.
//  Copyright © 2019 Shehana Aljaloud. All rights reserved.
//

import Foundation
import UIKit

class SendMemeCollectionViewCell: UICollectionViewCell{
    
    @IBOutlet var cellImageView: UIImageView!
}
