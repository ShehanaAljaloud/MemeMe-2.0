//
//  SendMemeTableViewCell.swift
//  MemeMe 1.0
//
//  Created by Shehana Aljaloud on 15/05/2019.
//  Copyright © 2019 Shehana Aljaloud. All rights reserved.
//


import UIKit

class SendMemeTableViewCell: UITableViewCell {
 
    @IBOutlet var cellImageView: UIImageView!
    @IBOutlet var topTextLabel: UILabel!
    @IBOutlet var bottomTextLabel: UILabel!
    
}
